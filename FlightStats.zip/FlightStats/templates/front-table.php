<?php
/**
 * Front-end shortcode template for APTS FlightStats Advanced.
 *
 * Shortcode: [apts_fs_flights]
 *
 * For now this uses a simple JS placeholder that:
 *  - Accepts flight numbers.
 *  - Renders a corporate-style table.
 *  - Shows "🛬 Check DAA" for each flight as a stub.
 *
 * Next step will be wiring this to real FlightStats data.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
?>

<div class="apts-fs-front">
    <form id="apts-fs-front-form">
        <h3>FlightStats – Internal Flight Tracking</h3>
        <p>Enter one or more flight numbers (e.g. FR553, EI521). Separate by comma or new line.</p>

        <textarea id="apts-fs-front-flights" rows="4" placeholder="FR553&#10;EI521"></textarea>

        <p>
            <button type="submit" class="button button-primary">Check Flight Status (FlightStats)</button>
        </p>

        <div id="apts-fs-front-message"></div>
    </form>

       <table class="apts-fs-table" id="apts-fs-front-table" style="display:none;">
        <thead>
            <tr>
                <th>Flight</th>
                <th>Origin</th>
                <th>Destination</th>
                <th>Status</th>
                <th>ETA (UTC)</th>
                <th>Delay</th>
                <th>Arrives In</th>
            </tr>
        </thead>
        <tbody></tbody>
    </table>

    <!-- Inline risk-colour CSS so it always loads, even with caching/minify -->
    <style>
        /* Status cell only – make it stand out */

        /* ON-TIME (green) */
        .apts-row-ontime .apts-status-cell {
            background: #c8f7c5 !important;
            font-weight: 700;
        }

        /* AT-RISK (amber) */
        .apts-row-atrisk .apts-status-cell {
            background: #ffe5a3 !important;
            font-weight: 700;
        }

        /* DELAYED (red) */
        .apts-row-delayed .apts-status-cell {
            background: #ffb3b3 !important;
            font-weight: 700;
        }

        /* NO DATA / CHECK DAA (blue) */
        .apts-row-checkdaa .apts-status-cell {
            background: #c7dbff !important;
            font-weight: 700;
        }

        /* Diverted – flashing red on status cell */
        .apts-row-diverted-flash .apts-status-cell {
            animation: apts-fs-diverted-flash 1.4s ease-in-out infinite alternate;
        }

        @keyframes apts-fs-diverted-flash {
            from { background-color: #ffb3b3; }
            to   { background-color: #ff8080; }
        }
    </style>

    <div class="apts-fs-note">
        Note: This v3 build renders the table and admin dashboard in the clean corporate airline style.
        The next step is wiring this front-end to the live FlightStats merged status engine and your
        "🛬 Check DAA" and budget shut-off rules.
    </div>
</div>

    <div class="apts-fs-note">
        Note: This v3 build renders the table and admin dashboard in the clean corporate airline style.
        The next step is wiring this front-end to the live FlightStats merged status engine and your
        "🛬 Check DAA" and budget shut-off rules.
    </div>
</div>
