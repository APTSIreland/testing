(function($){
    $(function(){

        var $form   = $('#apts-fs-front-form');
        var $ta     = $('#apts-fs-front-flights');
        var $msg    = $('#apts-fs-front-message');
        var $table  = $('#apts-fs-front-table');
        var $tbody  = $table.find('tbody');
        var $button = $form.find('button[type="submit"]');

        if (!$form.length) {
            return;
        }

        $form.on('submit', function(e){
            e.preventDefault();

            var raw = $ta.val() || '';
            raw = $.trim(raw);

            $msg.text('');
            $table.hide();
            $tbody.empty();

            if (!raw.length) {
                $msg.text('Please enter at least one flight number.');
                return;
            }

            if (typeof APTS_FS_FRONTEND === 'undefined') {
                $msg.text('Configuration error: front-end settings not found.');
                return;
            }

            var originalLabel = $button.text();
            $button.prop('disabled', true).text('Checking…');

            $.post(
                APTS_FS_FRONTEND.ajax_url,
                {
                    action:  'apts_fs_fetch_flights',
                    nonce:   APTS_FS_FRONTEND.nonce,
                    flights: raw
                }
            ).done(function(response){

                if (!response || !response.success) {
                    var err = 'Failed to fetch flight status.';
                    if (response && response.data && response.data.message) {
                        err = response.data.message;
                    }
                    $msg.text(err);
                    $table.hide();
                    return;
                }

                var data    = response.data || {};
                var flights = data.flights || [];

                if (!flights.length) {
                    $msg.text('No flights returned.');
                    $table.hide();
                    return;
                }

                flights.forEach(function(flt){
                    var flight      = flt.flight      || '';
                    var origin      = flt.origin      || '—';
                    var destination = flt.destination || '—';
                    var statusText  = flt.status      || '🛬 Check DAA';
                    var eta         = flt.eta_utc     || '—';
                    var delay       = flt.delay       || '—';
                    var arrivesIn   = flt.arrives_in  || '—';
                    var rowClass    = flt.row_class   || '';

                    var $tr = $('<tr/>');
                    if (rowClass) {
                        $tr.addClass(rowClass);
                    }

                    $tr.append(
                        $('<td/>').text(flight),
                        $('<td/>').text(origin),
                        $('<td/>').text(destination),
                        $('<td/>').addClass('apts-status-cell').text(statusText),
                        $('<td/>').text(eta),
                        $('<td/>').text(delay),
                        $('<td/>').addClass('apts-arrives').text(arrivesIn)
                    );

                    $tbody.append($tr);
                });

                var note = flights[0].note || '';
                if (note) {
                    $msg.text(note);
                } else {
                    $msg.text('');
                }

                $table.show();

            }).fail(function(){
                $msg.text('Unable to contact server. Please try again.');
                $table.hide();
            }).always(function(){
                $button.prop('disabled', false).text(originalLabel);
            });
        });

    });
})(jQuery);
